// Real data from alexsiri7/interstellarai.net repo + GitHub repos listing

const TENETS = [
  {
    title: "Ship small, ship often.",
    body: "A tool that explains itself in one sentence and solves one problem beats a suite of features nobody remembers. If we can't describe it without an em-dash, it's not done."
  },
  {
    title: "Automation is the default; humans are the escalation.",
    body: "Issues become PRs, PRs become deploys — without a human in the loop on the happy path. Humans step in when the machine gets stuck, not when it's working."
  },
  {
    title: "A broken pipeline is a bug, not a chore.",
    body: "If main is red or prod isn't shipping, something files an issue and fires Archon at it. We don't page humans for things a script can fix."
  },
  {
    title: "Staging is the gate, not a human click.",
    body: "Every backend has a staging environment with real E2E tests. The gate is the control — if staging passes, prod ships automatically."
  },
  {
    title: "One tool to master, many to serve.",
    body: "Archon drives the repeatable work across every project. Fixes there benefit every repo; regressions there break every repo — which is why Archon has its own staging, too."
  },
  {
    title: "Decisions are written down.",
    body: "If a choice affects more than one project — or will be forgotten in a month — it gets an ADR. The decision log is how future-us remembers why present-us did the weird thing."
  },
  {
    title: "Infrastructure follows shape, not vibe.",
    body: "Web backend? Railway + managed Postgres + staging. Mobile? GitHub Actions + signed artifact. Static? Cloudflare Pages. Pick the shape, inherit the pipeline. Deviations need an ADR."
  },
  {
    title: "Cost is bounded by design.",
    body: "AI credits, cron cadence, diagnostic cooldowns — the budget is part of the architecture. If a workflow can run away, it will. Build the leash first."
  }
];

const ADRS = [
  {
    number: 1,
    slug: "001-staging-before-prod",
    title: "Staging gate required before production",
    status: "accepted",
    date: "2026-04-18",
    summary: "Every backend service ships to staging first, runs E2E there, and only promotes to prod if the gate passes. Automated, no human click.",
    sections: [
      { h: "Context", ps: [
        "The portfolio uses AI-driven automation to ship code: issues are picked up by Archon, PRs are generated, CI runs, and merges happen without human review on the happy path. This compresses the feedback loop but also removes the human gate that traditionally catches \u201Clooks fine, breaks in prod\u201D regressions."
      ]},
      { h: "Decision", ps: [
        "Every backend service with a prod environment must have a staging environment that the automation deploys to first, and a set of smoke/E2E tests that run against staging. Prod deploys are gated on staging tests passing."
      ], ul: [
        "Staging uses a separate database (not prod with a flag). Schema changes run against real data shape before they hit prod data.",
        "E2E tests target the staging URL, not a mock. If staging is down, prod doesn't ship.",
        "The staging\u2192prod promotion is automated (no manual approval) so long as the gate passes \u2014 the gate is the control, not a human click."
      ]},
      { h: "Consequences", ul: [
        "<strong>More infra</strong>: every web backend needs two environments instead of one, plus a staging DB.",
        "<strong>Slower shipping</strong>: a commit takes ~5 more minutes to reach prod while staging deploys and tests run. Acceptable tradeoff.",
        "<strong>Higher confidence</strong>: regressions caught on staging never reach users, which is the whole point of automation-without-review."
      ]},
      { h: "Alternatives considered", ul: [
        "<strong>Manual approval in GH Actions deploy workflow</strong>: rejected. Adds a human step that breaks on weekends / while traveling. The point of automation is to keep shipping without a human in the loop.",
        "<strong>Feature flags in prod instead of staging env</strong>: rejected for backend-level regressions (DB migration errors, env-var misconfiguration) that flags don't catch. Flags stay for user-facing rollouts on top of the staging gate."
      ]}
    ]
  },
  {
    number: 2,
    slug: "002-pipeline-health-auto-fix",
    title: "Pipeline-health cron for self-healing automation",
    status: "accepted",
    date: "2026-04-18",
    projects: ["reli", "word-coach-annie", "filmduel", "cosmic-match", "un-reminder", "beads"],
    summary: "A fourth cron polls for meta-failures (red main, failed deploys, stalled pipelines) and fires Archon at itself when nothing else will.",
    sections: [
      { h: "Context", ps: [
        "The ecosystem relies on three crons to keep code flowing to prod: <code>issue-pickup-cron</code> picks open GH issues and launches Archon to draft fixes. <code>pr-maintenance-cron</code> merges clean PRs, rebases dirty ones, fixes failing CI.",
        "But these crons only work on happy-path inputs. Three failure modes exist where nothing comes back to fix the pipeline itself: main CI red, prod deploy failed or lagging, and pipeline stalled with no commits and no activity."
      ]},
      { h: "Decision", ps: [
        "A fourth cron, <code>pipeline-health-cron</code>, runs every 30 minutes and detects these meta-failures. When it finds one, it either files an issue tagged for Archon pickup (self-heal) or fires archon-assist directly (urgent bottleneck)."
      ], ul: [
        "<strong>Main CI red</strong> \u2192 file an <code>archon:in-progress</code>-tagged issue, fire Archon immediately on that issue, dedup by commit SHA via marker file.",
        "<strong>Prod deploy failed/lagging</strong> \u2192 same pattern, using deploy SHA for dedup; reads signal from the GH Actions deploy workflow or the GitHub deployments API.",
        "<strong>Zombie Archon DB runs</strong> (status=running, age &gt;4h) \u2192 abandon.",
        "<strong>Disk pressure</strong> &gt;85% \u2192 ntfy.",
        "<strong>No progress</strong> in last tick \u2014 if token-limit markers in logs, wait; else fire archon-assist diagnostic with 2h cooldown."
      ]},
      { h: "Consequences", ul: [
        "Self-healing covers three previously-silent failure modes.",
        "Zero cost when the pipeline is healthy \u2014 nothing fires.",
        "AI cost is bounded by the 2h diagnostic cooldown and per-SHA dedup.",
        "Adds one more thing to forget to deploy if the machine is reimaged \u2014 crontab lives in the memory reference file."
      ]},
      { h: "Alternatives considered", ul: [
        "<strong>Nagios / Uptime Kuma / PagerDuty</strong>: rejected. External monitoring tells you <em>that</em> something broke \u2014 the goal here is for the pipeline to fix <em>itself</em> without a human pager.",
        "<strong>Put the auto-fix inside each project's CI</strong>: rejected. CI only runs on push, so it can't detect \u201Cnothing happened for 30 minutes.\u201D Needs to be out-of-band."
      ]}
    ]
  },
  {
    number: 3,
    slug: "003-per-project-deploy-targets",
    title: "Default deploy stack per project shape",
    status: "accepted",
    date: "2026-04-18",
    summary: "Projects come in three shapes \u2014 web backend, mobile app, static site \u2014 and each inherits a proven deploy stack. Deviations need an ADR.",
    sections: [
      { h: "Context", ps: [
        "Projects fall into a small number of shapes, each with a different deploy story: web backends & full-stack apps, mobile apps, and static content. Rather than decide hosting fresh for every new project, we pick defaults per shape so a new project inherits a proven pipeline on day one."
      ]},
      { h: "Decision", table: {
        cols: ["Shape", "Default stack", "Build", "Rationale"],
        rows: [
          ["Web backend / full-stack", "Railway, managed Postgres, staging + prod", "GH Actions \u2192 Railway CLI", "Staging + managed DB are the two features that matter; Railway is the cheapest way to get both."],
          ["Mobile app", "GitHub Actions builds signed artifact", "Signed APK/AAB; store distribution manual", "Stores are the deploy target \u2014 no host needed."],
          ["Static site / docs", "Cloudflare Pages or GitHub Pages", "GH Actions auto-deploy on push to main", "Free, fast, pairs with DNS we already own."]
        ]
      }, ps: [
        "All web backends follow the staging-before-prod rule (ADR-001). All deploys post to the GitHub Deployments API so the pipeline-health monitor (ADR-002) can detect deploy regressions uniformly."
      ]},
      { h: "Consequences", ul: [
        "A new project inherits deploy infrastructure by choosing its shape. Deviations require an ADR.",
        "Three platforms stay in play (Railway, GitHub Actions, Cloudflare/GitHub Pages). Acceptable \u2014 each justifies a distinct deploy shape.",
        "DNS convention: everything under <code>*.interstellarai.net</code>. Cloudflare holds the zone."
      ]},
      { h: "Alternatives considered", ul: [
        "<strong>One platform for everything</strong>: no single host builds signed Android bundles <em>and</em> runs Postgres <em>and</em> serves static sites well. Rejected.",
        "<strong>Self-hosted for web backends</strong>: lower recurring cost, higher ops burden, single point of failure. Rejected.",
        "<strong>Vercel for Next.js web apps</strong>: possible, but splits the Postgres story across two vendors."
      ]}
    ]
  },
  {
    number: 4,
    slug: "004-archon-drives-automation",
    title: "Archon is the automation engine across all projects",
    status: "accepted",
    date: "2026-04-18",
    projects: ["reli", "word-coach-annie", "filmduel", "cosmic-match", "un-reminder"],
    summary: "One tool runs all the repeatable engineering work across the portfolio. Fixes in Archon benefit every project; regressions break every project.",
    sections: [
      { h: "Context", ps: [
        "Every project in the portfolio gets a steady stream of bugs, feature ideas, dependency bumps, and test gaps. Doing this by hand across six projects would be full-time work. We already built Archon \u2014 a YAML-driven AI coding harness \u2014 for exactly this purpose."
      ]},
      { h: "Decision", ps: [
        "Archon drives all repeatable engineering work across the portfolio:"
      ], ul: [
        "<strong>Issue \u2192 PR</strong>: <code>archon-fix-github-issue</code> converts an open issue into a drafted, CI-green, auto-merge-armed PR.",
        "<strong>Idea \u2192 PR</strong>: <code>archon-idea-to-pr</code> turns a short prose spec into a scoped PR.",
        "<strong>Test coverage</strong>: <code>archon-test-audit</code> finds under-tested modules and adds tests.",
        "<strong>Security</strong>: <code>archon-security-audit</code> runs static analysis and files remediation PRs.",
        "<strong>PR maintenance</strong>: <code>archon-pr-maintenance</code> rebases stale PRs and fixes their CI."
      ]},
      { h: "Consequences", ul: [
        "<strong>One tool to master, one tool to improve</strong>: fixes in Archon benefit every project. The flip side \u2014 regressions break every project \u2014 is mitigated by Archon having its own CI and staging.",
        "<strong>AI cost is nontrivial</strong>: workflows consume Anthropic credits. Bounded by per-project throttling, per-SHA dedup in the auto-fix layer, and quota-aware backoff.",
        "<strong>Archon itself is a project in the ecosystem</strong>, which means it also gets drivers and maintenance pressure."
      ]},
      { h: "How this interacts with other ADRs", ul: [
        "<strong>ADR-001 (staging before prod)</strong>: Archon doesn't bypass the staging gate \u2014 its PRs merge to <code>main</code> and then follow the same pipeline as human PRs.",
        "<strong>ADR-002 (pipeline-health cron)</strong>: Archon is also what gets fired by the health cron when something breaks. The cron is \u201CArchon of Archons\u201D \u2014 the supervisor that pokes Archon when Archon itself isn't making progress."
      ]}
    ]
  }
];

// Real repos from alexsiri7/* listing, grouped by shape
const PROJECTS = [
  // Web backend / full-stack
  { name: "reli", shape: "web", desc: "Web app. Part of the auto-Archon-driven portfolio.", stack: "Railway + Postgres", status: "live", repo: "alexsiri7/reli" },
  { name: "un-reminder", shape: "web", desc: "Stochastic, context-aware reminder app that defeats notification blindness.", stack: "Railway + Postgres", status: "live", repo: "alexsiri7/un-reminder" },
  { name: "filmduel", shape: "web", desc: "Discover and rank movies through pairwise comparisons, synced with Trakt.", stack: "Railway + Postgres", status: "live", repo: "alexsiri7/filmduel" },
  { name: "word-coach-annie", shape: "web", desc: "Language practice, quietly adaptive. Small dose, big leverage.", stack: "Railway + Postgres", status: "live", repo: "alexsiri7/word-coach-annie" },

  // Mobile
  { name: "cosmic-match", shape: "mobile", desc: "A space-themed match-3 mobile game built with Flutter + Flame.", stack: "Flutter + Flame", status: "live", repo: "alexsiri7/cosmic-match" },

  // Tooling / infra / agents
  { name: "archon", shape: "tooling", desc: "The first open-source harness builder for AI coding. Make AI coding deterministic and repeatable.", stack: "YAML-driven agent", status: "live", repo: "alexsiri7/Archon" },
  { name: "beads", shape: "tooling", desc: "A memory upgrade for your coding agent.", stack: "Agent memory", status: "live", repo: "alexsiri7/beads" },
  { name: "gastown", shape: "tooling", desc: "Multi-agent workspace manager.", stack: "Orchestration", status: "wip", repo: "alexsiri7/gastown" },
  { name: "gascity", shape: "tooling", desc: "Orchestration-builder SDK for multi-agent coding workflows.", stack: "SDK", status: "wip", repo: "alexsiri7/gascity" },

  // Static
  { name: "interstellarai.net", shape: "static", desc: "This site \u2014 plus the cross-project engineering handbook. Tenets, ADRs, conventions.", stack: "Astro + Cloudflare Pages", status: "live", repo: "alexsiri7/interstellarai.net" }
];

const SHAPES = [
  { id: "web", title: "Web backends", sub: "Railway + managed Postgres + staging. ADR-001 + ADR-003." },
  { id: "mobile", title: "Mobile apps", sub: "GitHub Actions builds signed artifacts. Stores handle the rest." },
  { id: "tooling", title: "Tooling & agents", sub: "The machines that run the machines. Archon and friends." },
  { id: "static", title: "Static sites", sub: "Cloudflare Pages or GitHub Pages. Free, fast, in-zone." }
];

Object.assign(window, { TENETS, ADRS, PROJECTS, SHAPES });
