// Page renderers for each route

const HomePage = ({ go, dir }) => (
  <>
    {dir === 'a' ? <HeroA go={go}/> : <HeroB go={go}/>}
    <HowItWorks go={go}/>
    <FeatureBlock go={go}/>
    <Portfolio go={go}/>
  </>
);

const HeroA = ({ go }) => (
  <section className="hero-a">
    <div className="wrap">
      <div>
        <Eyebrow>✶ interstellarai.net · est. 2026</Eyebrow>
        <h1>Small software, <em>shipped</em> by machines.</h1>
        <p className="lede">
          A portfolio of tiny AI-powered tools — and the engineering handbook that keeps them shipping. Automation drafts the PRs. Staging gates the deploys. Humans write the ADRs and drink the coffee.
        </p>
        <div className="ctas">
          <Button variant="primary" onClick={() => go('projects')}>See the projects →</Button>
          <Button variant="link" onClick={() => go('tenets')}>Read the tenets</Button>
        </div>
        <div className="hero-meta">
          <span>◉ 10 repos in orbit</span>
          <span>✶ 4 ADRs, counting</span>
          <span>· auto-deployed nightly</span>
        </div>
      </div>
      <div className="art">
        <img src="assets/illustration-orbit.svg" alt="" className="drift"/>
      </div>
    </div>
  </section>
);

const HeroB = ({ go }) => (
  <>
    <section className="hero-b">
      <div className="wrap">
        <div className="hero-grid">
          <div>
            <Eyebrow>✶ interstellarai.net · v0.4 · main is green</Eyebrow>
            <h1>An engineering handbook <em>for software</em> that writes itself.</h1>
            <p className="lede">
              AI drafts the PRs. Staging is the gate. A cron watches the cron. Ten small projects live in orbit around one shared pipeline — and everything worth remembering is written down here.
            </p>
            <div className="ctas">
              <Button variant="primary" onClick={() => go('decisions')}>Read the decisions →</Button>
              <Button variant="link" onClick={() => go('projects')}>See what's orbiting</Button>
            </div>
            <div className="hero-meta">
              <span>✷ 10 REPOS</span>
              <span>▲ 4 ADRS</span>
              <span>◉ ONE PIPELINE</span>
            </div>
          </div>
          <div className="diagram">
            <HeroDiagram/>
          </div>
        </div>
      </div>
    </section>
    <div className="marquee" style={{background:'#0F1115', color:'#EFE9DC'}}>
      <div className="marquee-track">
        {[...PROJECTS.filter(p => p.shape !== 'tooling'), ...PROJECTS.filter(p => p.shape !== 'tooling')].map((p, i) => (
          <React.Fragment key={i}>
            <span>{p.name}</span>
            <span className="dot">✶</span>
          </React.Fragment>
        ))}
      </div>
    </div>
  </>
);

const HowItWorks = ({ go }) => (
  <section className="how">
    <div className="wrap">
      <div className="how-cell">
        <div className="num">◯ 01</div>
        <h3>A human writes <em>an intent.</em></h3>
        <p>A GitHub issue, a two-line prose spec, or a sticky note scanned into Beads. The bar is low; the point is to start.</p>
        <div className="links">
          <a onClick={() => go('tenets')}>Why we write things down →</a>
        </div>
      </div>
      <div className="how-cell">
        <div className="num">◯ 02</div>
        <h3>A <em>small tool</em> drafts the PR.</h3>
        <p>A YAML-driven harness turns the intent into a PR: scoped, CI-green, auto-merge armed. It's not magic — it's 4,000 lines of config and a cron.</p>
        <div className="links">
          <a onClick={() => go('adr-004-one-automation-driver')}>ADR-004: one tool drives the portfolio →</a>
        </div>
      </div>
      <div className="how-cell">
        <div className="num">◯ 03</div>
        <h3>Staging <em>is the gate.</em></h3>
        <p>Merges roll to staging, E2E runs, prod promotes if the gate passes. A fourth cron watches the first three. No humans in the loop on the happy path.</p>
        <div className="links">
          <a onClick={() => go('adr-001-staging-before-prod')}>ADR-001 · ADR-002 →</a>
        </div>
      </div>
    </div>
  </section>
);

const FeatureBlock = ({ go }) => (
  <section className="feature">
    <div className="wrap">
      <div className="feature-art">
        <svg viewBox="0 0 400 400" fill="none" aria-hidden="true">
          <rect x="30" y="30" width="340" height="340" rx="8" stroke="currentColor" strokeWidth="1.5" opacity="0.3" fill="none"/>
          <g transform="translate(200 200)">
            <circle r="60" fill="#D97757"/>
            <circle r="24" fill="#FAF7F2"/>
            <text y="6" textAnchor="middle" fontFamily="Instrument Serif" fontStyle="italic" fontSize="14" fill="#1A1A1A">pipeline</text>
          </g>
          <g stroke="currentColor" strokeWidth="1.2" opacity="0.6">
            <line x1="200" y1="80" x2="200" y2="130"/>
            <line x1="200" y1="270" x2="200" y2="320"/>
            <line x1="80" y1="200" x2="130" y2="200"/>
            <line x1="270" y1="200" x2="320" y2="200"/>
          </g>
          <g fontFamily="JetBrains Mono, monospace" fontSize="10" fill="currentColor" opacity="0.7" letterSpacing="1">
            <text x="200" y="70" textAnchor="middle">ISSUE → PR</text>
            <text x="200" y="340" textAnchor="middle">TESTS → MERGE</text>
            <text x="70" y="205" textAnchor="end">IDEA</text>
            <text x="330" y="205">DEPLOY</text>
          </g>
        </svg>
      </div>
      <div>
        <Eyebrow>✷ the automation engine</Eyebrow>
        <h2>One pipeline drives <em>every project</em>.</h2>
        <p>
          GitHub issues become auto-merged PRs. PR rebases, test gaps, security audits — all handled. A fourth cron watches the first three and fires remediation workflows when the pipeline itself gets stuck. It's the "supervisor of supervisors" pattern: a cron that pokes the worker when the worker gets stuck.
        </p>
        <p>
          When we hit a rough edge, we patch the tooling upstream. The automation itself ships through the same staging gate it powers. Very <em>ouroboros</em>. Very on-brand.
        </p>
        <Button variant="secondary" onClick={() => go('adr-004-one-automation-driver')}>Read ADR-004 →</Button>
      </div>
    </div>
  </section>
);

const Portfolio = ({ go }) => {
  const visible = PROJECTS.filter(p => p.shape !== 'tooling').slice(0, 8);
  return (
    <section className="portfolio">
      <div className="wrap">
        <div className="section-head">
          <div>
            <Eyebrow>✷ in orbit</Eyebrow>
            <h2 className="section-title">Ten projects, <em>one pipeline.</em></h2>
          </div>
          <Button variant="secondary" size="sm" onClick={() => go('projects')}>All projects →</Button>
        </div>
        <div className="portfolio-grid">
          {visible.map(p => (
            <a key={p.name} className="pf-card"
               href={`https://github.com/${p.repo}`} target="_blank" rel="noreferrer">
              <div className="row">
                <span className="mono" style={{fontSize:11, opacity:0.6, textTransform:'uppercase', letterSpacing:'0.04em'}}>· {p.shape}</span>
                {p.status === 'live' && <Badge tone="live"><span className="dot"/>live</Badge>}
                {p.status === 'wip' && <Badge tone="wip">wip</Badge>}
              </div>
              <h3 className="name"><em>{p.name}</em></h3>
              <p className="blurb">{p.desc}</p>
              <div className="foot">
                <span>{p.stack}</span>
                <span>→</span>
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
};

// ======================= TENETS =======================
const TenetsPage = ({ go }) => (
  <>
    <section style={{paddingTop:'var(--sp-8)', paddingBottom:'var(--sp-5)'}}>
      <div className="wrap-prose">
        <Eyebrow>✷ the handbook</Eyebrow>
        <h1 style={{fontFamily:'var(--font-display)', fontSize:'clamp(2.8rem, 6vw, 4.5rem)', lineHeight:1.15, letterSpacing:'-0.02em', margin:'var(--sp-2) 0 var(--sp-5)', fontWeight:400, paddingBottom:'0.2em', display:'block'}}>
          <span style={{display:'block'}}>Non-negotiables.</span>
          <em style={{fontStyle:'italic', color:'var(--terracotta)', display:'block'}}>Eight of them.</em>
        </h1>
        <p style={{fontSize:18, lineHeight:1.6, color:'var(--fg-muted)', maxWidth:'60ch', textWrap:'pretty'}}>
          These are the principles we don't re-argue. If a decision contradicts a tenet, the tenet wins — or the tenet changes and gets a receipt (that's an ADR). They're short on purpose. If a tenet needs a paragraph to justify itself, it's probably a decision record, not a tenet.
        </p>
      </div>
    </section>
    <section style={{paddingTop:'var(--sp-4)'}}>
      <div className="wrap-prose">
        <ol className="tenets-list">
          {TENETS.map((t, i) => (
            <li key={i} className="tenet">
              <div className="tenet-num"></div>
              <div>
                <h3 dangerouslySetInnerHTML={{__html: t.title.replace(/(\b[a-z]+\b)(?=\.\s*$)/i, '<em>$1</em>')}}/>
                <p>{t.body}</p>
              </div>
            </li>
          ))}
        </ol>
        <p style={{marginTop:'var(--sp-7)', color:'var(--fg-muted)', fontSize:14, textWrap:'pretty'}}>
          Disagree with a tenet? Open an issue on <a onClick={() => window.open('https://github.com/alexsiri7/interstellarai.net', '_blank')} style={{cursor:'pointer', color:'var(--slate)'}}>the handbook repo</a>, write the counter-argument, and if it holds up, it becomes an ADR that supersedes the tenet. That's how the handbook changes.
        </p>
      </div>
    </section>
  </>
);

// ======================= DECISIONS INDEX =======================
const DecisionsPage = ({ go }) => {
  const [filter, setFilter] = React.useState('all');
  const list = filter === 'all' ? ADRS : ADRS.filter(a => a.status === filter);
  return (
    <>
      <section style={{paddingTop:'var(--sp-8)', paddingBottom:'var(--sp-5)'}}>
        <div className="wrap-prose">
          <Eyebrow>✷ decision log</Eyebrow>
          <h1 style={{fontFamily:'var(--font-display)', fontSize:'clamp(2.8rem, 6vw, 4.5rem)', lineHeight:1.12, letterSpacing:'-0.02em', margin:'var(--sp-2) 0 var(--sp-5)', fontWeight:400, textWrap:'balance', paddingBottom:'0.12em'}}>
            Why we did the <em style={{fontStyle:'italic', color:'var(--terracotta)'}}>weird thing.</em>
          </h1>
          <p style={{fontSize:18, lineHeight:1.6, color:'var(--fg-muted)', maxWidth:'60ch', textWrap:'pretty'}}>
            Architecture Decision Records. Each one captures context, the call we made, what it costs us, and what we considered instead. Chronological, append-only, supersedable. If you want to understand why the portfolio is shaped the way it is, start here.
          </p>
        </div>
      </section>
      <section style={{paddingTop:'var(--sp-2)'}}>
        <div className="wrap-prose">
          <div className="filter-row">
            <span className="filter-label">status ·</span>
            {['all', 'accepted', 'proposed', 'superseded', 'deprecated'].map(s => (
              <button key={s} className={`chip ${filter === s ? 'is-on' : ''}`} onClick={() => setFilter(s)}>{s}</button>
            ))}
          </div>
          <ul className="decisions">
            {list.map(a => (
              <a key={a.number} className="dec"
                 href={`#/adr/${a.slug}`}
                 onClick={(e) => { e.preventDefault(); go(`adr-${a.slug}`); }}>
                <span className="num">ADR-{String(a.number).padStart(3,'0')}</span>
                <span className="title">{a.title}</span>
                <span className="meta-date">{a.date}</span>
                <span className="meta-status"><Badge tone={a.status}>{a.status}</Badge></span>
              </a>
            ))}
          </ul>
          {list.length === 0 && (
            <p style={{color:'var(--fg-muted)', padding:'var(--sp-5) 0'}}>Nothing with that status yet. The log is young.</p>
          )}
          <p style={{marginTop:'var(--sp-6)', color:'var(--fg-subtle)', fontSize:13, fontFamily:'var(--font-mono)', letterSpacing:'0.04em'}}>
            · {ADRS.length} decisions · last updated {ADRS[ADRS.length-1].date} ·
          </p>
        </div>
      </section>
    </>
  );
};

// ======================= ADR DETAIL =======================
const AdrPage = ({ slug, go }) => {
  const adr = ADRS.find(a => a.slug === slug) || ADRS[0];
  const idx = ADRS.indexOf(adr);
  const prev = ADRS[idx - 1];
  const next = ADRS[idx + 1];
  return (
    <>
      <section className="adr-head">
        <div className="wrap-prose">
          <div className="crumbs">
            <a onClick={() => go('decisions')}>← Decision log</a>
            <span style={{opacity:0.5, margin:'0 8px'}}>/</span>
            <span>ADR-{String(adr.number).padStart(3,'0')}</span>
          </div>
          <h1>{adr.title.replace(/\.$/, '')}.</h1>
          <div className="adr-meta">
            <span><strong>ADR-{String(adr.number).padStart(3,'0')}</strong></span>
            <span>· <Badge tone={adr.status}>{adr.status}</Badge></span>
            <span>· {adr.date}</span>
            {adr.projects && <span>· affects: {adr.projects.join(', ')}</span>}
          </div>
        </div>
      </section>
      <section className="adr-body">
        <div className="wrap-prose">
          {adr.summary && (
            <p style={{fontFamily:'var(--font-display)', fontStyle:'italic', fontSize:22, lineHeight:1.4, color:'var(--ink)', borderLeft:'3px solid var(--terracotta)', paddingLeft:'var(--sp-4)', margin:'0 0 var(--sp-7)'}}>
              {adr.summary}
            </p>
          )}
          {adr.sections.map((s, i) => (
            <div key={i}>
              <h2>{s.h}</h2>
              {s.ps && s.ps.map((p, j) => (
                <p key={j} dangerouslySetInnerHTML={{__html: p}}/>
              ))}
              {s.ul && (
                <ul>
                  {s.ul.map((li, j) => <li key={j} dangerouslySetInnerHTML={{__html: li}}/>)}
                </ul>
              )}
              {s.table && (
                <table className="adr-table">
                  <thead><tr>{s.table.cols.map((c, j) => <th key={j}>{c}</th>)}</tr></thead>
                  <tbody>
                    {s.table.rows.map((r, j) => (
                      <tr key={j}>{r.map((c, k) => <td key={k}>{c}</td>)}</tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          ))}
          <div className="adr-nav">
            <div>
              {prev && (
                <a onClick={() => go(`adr-${prev.slug}`)}>
                  ← ADR-{String(prev.number).padStart(3,'0')}
                  <span>{prev.title}</span>
                </a>
              )}
            </div>
            <div style={{textAlign:'right'}}>
              {next && (
                <a onClick={() => go(`adr-${next.slug}`)}>
                  ADR-{String(next.number).padStart(3,'0')} →
                  <span>{next.title}</span>
                </a>
              )}
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

// ======================= PROJECTS =======================
const ProjectsPage = ({ go }) => (
  <>
    <section className="pf-hero">
      <div className="wrap">
        <Eyebrow>✷ the catalog</Eyebrow>
        <h1>Ten small things, <em>shipped</em> and shipping.</h1>
        <p>
          The portfolio. Tools, games, agents, and the handbook you're reading. Each one does one thing. If it can't be described in a sentence, it's not done yet.
        </p>
      </div>
    </section>
    <section className="pf-body">
      <div className="wrap">
        <div className="pf-list-row">
          {PROJECTS.map(p => (
            <a key={p.name} className="pf-row pf-row-simple"
               href={`https://github.com/${p.repo}`} target="_blank" rel="noreferrer">
              <div className="name"><em>{p.name}</em></div>
              <div className="desc">{p.desc}</div>
              <div className="status">
                {p.status === 'live' && <Badge tone="live"><span className="dot"/>live</Badge>}
                {p.status === 'wip' && <Badge tone="wip">wip</Badge>}
                {p.status === 'archive' && <Badge tone="archive">archive</Badge>}
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  </>
);

Object.assign(window, { HomePage, TenetsPage, DecisionsPage, AdrPage, ProjectsPage });
