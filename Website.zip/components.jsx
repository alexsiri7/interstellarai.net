// Shared primitives used across pages

const Wordmark = ({ inverse = false }) => (
  <span className="nav-brand">
    <svg width="28" height="28" viewBox="0 0 64 64" fill="none" aria-hidden="true" style={{flexShrink:0}}>
      <ellipse cx="32" cy="32" rx="26" ry="10" transform="rotate(-24 32 32)"
        stroke={inverse ? '#FAF7F2' : 'currentColor'} strokeWidth="2.5" fill="none"/>
      <ellipse cx="32" cy="32" rx="20" ry="8" transform="rotate(24 32 32)"
        stroke={inverse ? '#FAF7F2' : 'currentColor'} strokeWidth="1.2" fill="none" opacity="0.6" strokeDasharray="2 3"/>
      <circle cx="32" cy="32" r="6" fill="#D97757"/>
      <circle cx="52" cy="22" r="2.2" fill={inverse ? '#FAF7F2' : 'currentColor'}/>
    </svg>
    <span>
      <em>Interstellar</em><span className="ai">AI</span>
    </span>
  </span>
);

const Button = ({ children, variant = 'primary', size = 'md', onClick, href, ...rest }) => {
  const cls = `btn btn-${variant} btn-${size}`;
  if (href) return <a className={cls} href={href} onClick={onClick} {...rest}>{children}</a>;
  return <button className={cls} onClick={onClick} {...rest}>{children}</button>;
};

const Badge = ({ children, tone = 'neutral' }) => (
  <span className={`badge badge-${tone}`}>{children}</span>
);

const Eyebrow = ({ children }) => <div className="eyebrow">{children}</div>;

const Nav = ({ route, go }) => {
  const items = [
    { id: 'home', label: 'Home' },
    { id: 'tenets', label: 'Tenets' },
    { id: 'decisions', label: 'Decisions' },
    { id: 'projects', label: 'Projects' },
  ];
  return (
    <nav className="nav">
      <div className="nav-inner">
        <a className="nav-brand" href="#/" onClick={(e)=>{e.preventDefault(); go('home');}}>
          <Wordmark/>
        </a>
        <div className="nav-links">
          {items.map(i => (
            <button key={i.id}
              className={`nav-link ${route === i.id || (i.id==='decisions' && route==='adr') ? 'is-active' : ''}`}
              onClick={() => go(i.id)}>
              {i.label}
            </button>
          ))}
        </div>
        <div className="nav-right">
          <a className="nav-ghost-link" href="https://github.com/alexsiri7/interstellarai.net" target="_blank" rel="noreferrer">
            github ↗
          </a>
        </div>
      </div>
    </nav>
  );
};

const Footer = ({ go }) => (
  <footer className="footer">
    <div className="footer-inner">
      <div>
        <div className="brand">
          <svg width="30" height="30" viewBox="0 0 64 64" fill="none" aria-hidden="true">
            <ellipse cx="32" cy="32" rx="26" ry="10" transform="rotate(-24 32 32)" stroke="#FAF7F2" strokeWidth="2.5" fill="none"/>
            <circle cx="32" cy="32" r="6" fill="#D97757"/>
            <circle cx="52" cy="22" r="2.5" fill="#FAF7F2"/>
          </svg>
          <span><em>Interstellar</em><span className="ai">AI</span></span>
        </div>
        <p className="tagline">Small, AI-driven software projects and the engineering handbook that keeps them shipping.</p>
      </div>
      <div className="footer-cols">
        <div>
          <div className="footer-h">Handbook</div>
          <a onClick={() => go('tenets')}>Tenets</a>
          <a onClick={() => go('decisions')}>Decision log</a>
          <a onClick={() => go('projects')}>Projects</a>
        </div>
        <div>
          <div className="footer-h">Projects</div>
          <a href="https://filmduel.interstellarai.net" target="_blank" rel="noreferrer">FilmDuel</a>
          <a href="https://github.com/alexsiri7/Archon" target="_blank" rel="noreferrer">Archon</a>
          <a href="https://github.com/alexsiri7/un-reminder" target="_blank" rel="noreferrer">un-reminder</a>
          <a href="https://github.com/alexsiri7/cosmic-match" target="_blank" rel="noreferrer">Cosmic Match</a>
        </div>
        <div>
          <div className="footer-h">Elsewhere</div>
          <a href="https://github.com/alexsiri7" target="_blank" rel="noreferrer">GitHub</a>
          <a>RSS</a>
          <a>Field notes</a>
          <a>mail@interstellarai.net</a>
        </div>
      </div>
    </div>
    <div className="footer-foot">
      <span>© 2026 InterstellarAI · Made in orbit</span>
      <span>✶ Deployed via the pipeline · Cloudflare Pages</span>
    </div>
  </footer>
);

// Orbital diagram for the dark hero — a "portfolio orbiting archon" metaphor
const HeroDiagram = () => (
  <svg viewBox="0 0 460 460" fill="none" aria-hidden="true">
    <defs>
      <pattern id="diag-dots" x="0" y="0" width="24" height="24" patternUnits="userSpaceOnUse">
        <circle cx="1" cy="1" r="0.8" fill="#EFE9DC" opacity="0.12"/>
      </pattern>
    </defs>
    <rect width="460" height="460" fill="url(#diag-dots)"/>
    {/* outer orbits */}
    <ellipse cx="230" cy="230" rx="200" ry="80" transform="rotate(-22 230 230)" stroke="#EFE9DC" strokeWidth="1" opacity="0.25" fill="none"/>
    <ellipse cx="230" cy="230" rx="150" ry="60" transform="rotate(22 230 230)" stroke="#D97757" strokeWidth="1.2" fill="none" opacity="0.7"/>
    <ellipse cx="230" cy="230" rx="100" ry="40" transform="rotate(-8 230 230)" stroke="#EFE9DC" strokeWidth="1" opacity="0.3" strokeDasharray="2 4" fill="none"/>

    {/* center: archon */}
    <circle cx="230" cy="230" r="24" fill="#D97757"/>
    <circle cx="230" cy="230" r="10" fill="#0F1115"/>
    <text x="230" y="278" textAnchor="middle" fontFamily="Instrument Serif, serif" fontStyle="italic" fontSize="16" fill="#EFE9DC">interstellar</text>
    <text x="230" y="296" textAnchor="middle" fontFamily="Geist, sans-serif" fontSize="11" fill="#D97757" letterSpacing="2">AI</text>

    {/* satellite projects */}
    <g fontFamily="Instrument Serif, serif" fontStyle="italic" fontSize="14" fill="#EFE9DC">
      <circle cx="410" cy="160" r="5" fill="#EFE9DC"/>
      <text x="422" y="164">filmduel</text>

      <circle cx="76" cy="308" r="4" fill="#E8A33D"/>
      <text x="24" y="330">reli</text>

      <circle cx="340" cy="360" r="4" fill="#EFE9DC"/>
      <text x="260" y="380">un-reminder</text>

      <circle cx="110" cy="140" r="3" fill="#6B8E5A"/>
      <text x="44" y="134">cosmic-match</text>

      <circle cx="410" cy="290" r="3" fill="#EFE9DC"/>
      <text x="310" y="286">word-coach-annie</text>
    </g>

    {/* tiny callouts */}
    <g stroke="#EFE9DC" strokeWidth="0.8" opacity="0.3">
      <line x1="230" y1="230" x2="410" y2="160"/>
      <line x1="230" y1="230" x2="76" y2="308"/>
      <line x1="230" y1="230" x2="340" y2="360"/>
    </g>
  </svg>
);

Object.assign(window, { Wordmark, Button, Badge, Eyebrow, Nav, Footer, HeroDiagram });
